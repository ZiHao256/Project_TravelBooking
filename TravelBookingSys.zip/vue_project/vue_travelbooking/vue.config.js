module.exports = {
  assetsDir: 'static',
  lintOnSave: false
}
